extends Node2D

var num = 1 
var txt = 1

func _ready():
	var img1 = "imagem" + str(num)
	load_image(img1)
	var text1 = "texto" + str(txt)
	load_text(text1)
	
func load_image(img_name: String): 
	var http_request = HTTPRequest.new()
	add_child(http_request)
	http_request.request_completed.connect(self._image_http_request_completed)
	var url = "https://raw.githubusercontent.com/Thigogomes/CC-PUC/main/PPB/T1/img/" + img_name + ".png"
	print("Carregando imagem...")
	http_request.request(url)
	
func _image_http_request_completed(result, response_code, headers, body):
	var image = Image.new()
	if image.load_png_from_buffer(body) != OK: 
		push_error("Erro img1")
		print("Erro ao carregar imagem!")
	else:
		print("Imagem carregada com sucesso!")
		var tex = ImageTexture.create_from_image(image)
		$CanvasLayer/Button_img1/Sprite1.texture = tex
		$CanvasLayer/Button_img1/Sprite1.scale = Vector2(350, 680)/tex.get_size()
		
func load_text(text_name: String):
	var http_request = HTTPRequest.new()
	add_child(http_request)
	http_request.request_completed.connect(self._text_http_request_completed)
	var url = "https://raw.githubusercontent.com/Thigogomes/CC-PUC/main/PPB/T1/" + text_name + ".txt"
	var error = http_request.request(url)
	if error != OK:
		push_error("Erro ao requisitar texto.")


func _text_http_request_completed(result, response_code, headers, body):
	#self.text = body.get_string_from_utf8()
	var text_content = body.get_string_from_utf8()
	$CanvasLayer/Label.text = text_content
	var fonte = load("res://fonts/PressStart2P-Regular.ttf")
	var tamanho = 16  # tamanho da fonte

	$CanvasLayer/Label.add_theme_font_override("font", fonte)
	$CanvasLayer/Label.add_theme_font_size_override("font_size", tamanho)

	
func _on_button_img_1_pressed() -> void:
	pass

func _on_button_text_1_pressed() -> void:
	pass

func _on_prox_pressed() -> void:
	if txt < 5:
		txt = txt + 1
	if num < 5:
		num = num + 1
	var img = "imagem" + str(num) 
	var text = "texto" + str(txt)
	load_image(img)
	load_text(text)

func _on_ant_pressed() -> void:
	if txt > 1:
		txt = txt - 1
	if num > 1:
		num = num - 1
	var img = "imagem" + str(num)
	var text = "texto" + str(txt)
	load_image(img)
	load_text(text)
