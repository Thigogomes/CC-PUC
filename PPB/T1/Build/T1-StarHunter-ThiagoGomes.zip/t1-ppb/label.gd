extends Label
